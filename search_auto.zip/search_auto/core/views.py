import json

from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from core.models import search


def autocomplete(request):
    if 'term' in request.GET:
        qs = search.objects.filter(title__icontains=request.GET.get('term'))
        titles = list()
        for search in qs:
            titles.append(product.title)
        # titles = [product.title for product in qs]
        return JsonResponse(titles, safe=False)
    return render(request, 'core/home.html')